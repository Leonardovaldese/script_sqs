import boto3
import json
import os

# Creazione di un client SQS
sqs_client = boto3.client("sqs")

# Funzione per inviare un messaggio JSON alla coda SQS
def send_message_to_sqs(message_body, queue_url):
    response = sqs_client.send_message(
        QueueUrl=queue_url,
        MessageBody=json.dumps(message_body),
    )
    return response

# Funzione per generare e inviare il messaggio JSON del veicolo
def generate_and_send_vehicle_message(queue_url):
    # Genera le informazioni sul veicolo
    message = {
        "vehicleId": "VH2001",
        "marca": "Honda",
        "modello": "Civic",
        "anno": 2020,
        "colore": "Blu",
        "chilometraggio": 15000
    }

    # Invia il messaggio alla coda SQS
    response = send_message_to_sqs(message, queue_url)

    print(f"MessageId: {response['MessageId']}")
    print(f"Message body: {json.dumps(message, indent=2)}")


# Funzione principale invocata da Lambda
def lambda_handler(event, context):
    # Recupera l'URL della coda SQS dalle variabili d'ambiente o dai parametri di configurazione
    queue_url = os.environ.get('QUEUE_URL')
    
    if queue_url:
        generate_and_send_vehicle_message(queue_url)
    else:
        print("URL della coda SQS non trovato. Assicurati che sia stato configurato correttamente.")
